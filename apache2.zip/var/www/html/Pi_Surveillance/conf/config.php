<?php
mysql_connect("localhost", "root", "raspberry") or die ("Sorry, unable to connect to database.");
mysql_select_db("camerasurveillance");

?>
