<?php 

$form = ("
<html>
	<head>
		<style>
			body
			{
				margin: 40px;
				padding: 5px;
			}
			img
			{
				width: 45%;
				height: 75%;
			}
		</style>
	</head>
	<body>
		<!-- The address of your Pi in this line: -->
		<img src='http://192.168.0.4:8092/' />
		<!-- <img src='http:109.255.31.61:8091' /> -->
	</body>
</html>
");

echo $form; 

?>
