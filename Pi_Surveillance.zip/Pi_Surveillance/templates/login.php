<?php

error_reporting(0);
include('../conf/config.php') or die ("Cannot find config file.");

if(isset($_POST['submit'])) 
{ 
$email = mysql_escape_string($_POST['email']); 
$password = mysql_escape_string($_POST['password']); 
$password = md5($password); 

$check = mysql_query("SELECT * FROM `users` WHERE `email` = '$email' AND `password` = '$password'"); 
if(mysql_num_rows($check) >= 1)
{ echo "You are now logged in!"; 
header("../templates/cam.html"); /* Redirect browser */
exit(); 
}else{ 
	echo "Wrong password"; 
} 

} else{ 
$form = ("<td> 
<form action='login.php' method='POST'> 
Username: <input type='text' name='emaill'><br> 
Password: <input type='password' name='password'><br> 
<input type='submit' name='submit' value='Log in'> 
</form>
</td>");

echo $form; 
} 

?>