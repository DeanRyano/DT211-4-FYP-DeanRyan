<html>
<head>
<title>Camera/Media View</title>
</head>
<body>
<?php
include('../conf/config.php');
include('../templates/func.php');
include('../templates/title_bar.php');
?>

<!--<h3 style="color:white;">Camera View Page</h3> -->
<?php 
if($user_level == 1){
	echo " 
<div style='position: absolute; top: 8px; right: 150px;'>
	<link rel='stylesheet' type='text/css' href='../css/popdown.css'/>
	<script src='../scripts/popdown.js'></script> 
		<div class='dropdown'>
			<button onclick='myFunction()' style='position: absolute; top: 0px; right: -65px;' class='dropbtn'>Settings</button>
			<div id='myDropdown' class='dropdown-content'>
				<a href='add_user.php'>Add Users</a>
				<a href='edit_user.php'>Edit Users</a>
				<a href='change_cam.php'>Change Cam</a>
				<a href='change_media.php'>Change Media</a>
			</div>
		</div>
</div >
<div>
<button onclick='window.location.href='logout.php'' style='position: absolute; top: 175px; right: 600px;' class='dropbtn'>Delete Media</button>;
</div>
";
}
?>
		 		 
		 
<div style='position: absolute; top: 120px; left: 80px;'>		 
		 <img  id='this' src='http://192.168.0.4:8092/' style='width:600px; height: 400px;' border='5'/>
		 <iframe id='img1' style='background: #FFFFFF; width:600px; height: 300px;' src='http://192.168.0.4:8094/' />
</div>
</body>
</html>
