<html>
<head>
<title>Edit User Credentials</title>
</head>
<body>
<?php
include('../conf/config.php');
include('../templates/func.php');
include('../templates/title_bar.php');
?>

<h3> Edit User: </h3>

<form method='post'>
<?php

echo '<h2>Current Users:</h2>';

$sql    = "SELECT `username`
           FROM `users`
           ORDER BY `id` ASC";

$result = mysql_query($sql);

while($user = mysql_fetch_array($result))
    echo $user['username']. '<br/>';
?>



</body>
</html>