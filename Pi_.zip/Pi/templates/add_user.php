<html>
<head>
<title>Add New User/Admin</title>
</head>
<body>
<?php
include('../conf/config.php');
include('../templates/func.php');
include('../templates/title_bar.php');
?>

<h3> Add User: </h3>

<form method='post'>
<?php
if(isset($_POST['submit'])){
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	$user_level = $_POST['user_level'];
	$user_type = $_POST['user_type'];
	if(empty($username) or empty($password) or empty($user_level) or empty($user_type)){
		echo "<p> Fields Empty !</p>";
	}else{
		mysql_query("INSERT INTO users VALUES('', '$username', '$password', '$user_level', '$user_type')");
		echo "<p>Add Successful</p>";
		header('Refresh: 2;cam_view.php');

	}
}
?>

<div class='login' style='position: absolute; top: 240px;'>
<form id='thisform'>
User Name: <br/>
<input type='text' name='username' />
<br/><br/>
Password : <br/>
<input type='password' name='password'>
<br/><br/>
User_level : <br/>
<input type='text' name='user_level' />
<br/><br/>
Type : <br/>
<input type='text' name='user_type'>
<br/><br/>

<button type="submit" name='submit' class="btn btn-primary btn-block btn-large">ADD USER</button>
</div>

</body>
</html>