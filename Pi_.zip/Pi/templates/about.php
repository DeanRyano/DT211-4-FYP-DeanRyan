<html>
<head>
<title>About Pi-Surveillance</title>
</head>
<body>
<?php
include('../conf/config.php');
include('../templates/func.php');
include('../templates/title_bar.php');
?>

<h3 style="color:white;"> Login Here: </h3>



</body>
</html>
